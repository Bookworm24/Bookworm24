import cv2
import numpy as np
from pyzbar.pyzbar import decode
import pyzbar
import os
"""
pyzbar库是一个用于条形码和二维码解码的Python库。它基于ZBar库，可以识别并解码图像中的条形码和二维码。pyzbar库提供了一个简单易用的接口，可以方便地在Python程序中集成条形码和二维码的解码功能。

使用pyzbar库，你可以读取图像文件或者实时视频流中的条形码和二维码，并获取它们的内容。它支持多种常见的条形码和二维码格式，包括EAN-13、UPC-A、QR码等。

在上面的例子中，我们使用pyzbar库来解码摄像头捕获的图像中的条形码。通过调用`decode`函数，我们可以获取到条形码的内容，并将其打印出来。然后，我们使用OpenCV库绘制了条形码的边框和文本，以便在图像中进行可视化展示。

pyzbar库提供了一个简单而强大的方式来处理条形码和二维码的解码任务，使得在Python中进行条形码和二维码的识别变得更加方便和高效。

如果你有任何其他问题，请随时提问！
"""
# 设置libzbar-64.dll文件的路径

"""
在使用OpenCV进行图像处理时，有时需要对点集进行重塑（reshape）。`pts = pts.reshape((-1,1,2))`的目的是将点集`pts`的形状从`(n, 2)`重塑为`(n, 1, 2)`。

这种重塑的常见情况是为了与OpenCV中的某些函数的输入要求相匹配。例如，当使用`cv2.polylines()`函数绘制多边形时，它要求点集的形状为`(n, 1, 2)`，其中`n`是点的数量。

重塑操作的具体含义是将原始点集的维度从`(n, 2)`转换为`(n, 1, 2)`。这样做的目的是为了确保点集的维度与函数的输入要求相匹配。在这种情况下，点集中的每个点都被表示为一个单独的数组，其中每个点的坐标由一个长度为2的数组表示。

例如，如果原始点集`pts`是一个形状为`(4, 2)`的数组，表示四个点的坐标，如下所示：

```
pts = np.array([[10, 20],
                [30, 40],
                [50, 60],
                [70, 80]])
```

通过执行`pts = pts.reshape((-1,1,2))`操作，将其重塑为形状为`(4, 1, 2)`的数组：

```
pts = np.array([[[10, 20]],
                [[30, 40]],
                [[50, 60]],
                [[70, 80]]])
```

现在，点集`pts`的形状与`cv2.polylines()`函数的输入要求相匹配，可以直接将其用作函数的参数。

需要注意的是，重塑操作并不改变点集中的数据，只是改变了其形状。因此，重塑后的点集仍然包含相同的点坐标，只是以不同的维度表示。

希望这解释清楚了为什么要进行`pts = pts.reshape((-1,1,2))`操作。如果你有任何其他问题，请随时提问。在，pts是一个三维数组，其中每个元素都是一个形状为(1, 2)的数组。我们可以通过索引来访问每个点的坐标。例如，pts[0]表示第一个点，
它是一个形状为(1, 2)的数组[[10, 20]]。同样，pts[1]表示第二个点，pts[2]表示第三个点，以此类推。
"""
img = cv2.imread('../image/32.png')
# cap = cv2.VideoCapture(0)
# cap.set(3,640)
# cap.set(4,480)

# while True:

#     # success, img = cap.read()
for barcode in decode(img):#因此，barcode.data.decode('utf-8')返回的是条形码对象的数据，经过UTF-8解码后得到的字符串。这个字符串可以表示条形码所包含的实际信息，例如产品代码、序列号等。
    myData = barcode.data.decode('utf-8')
    print(myData)
    pts = np.array([barcode.polygon],np.int32)#条形码对象通常包含有关条形码位置的信息，例如条形码的边界框或多边形。barcode.polygon是一个表示条形码多边形坐标的列表或数组。

# 通过使用np.array()函数，我们将barcode.polygon作为参数传递给函数，并指定数据类型为np.int32，这表示我们希望将多边形坐标转换为32位整数类型的NumPy数组。
    pts = pts.reshape((-1,1,2))#将其调整为能够使用polylines画图的
    cv2.polylines(img,[pts],True,(0,255,0),5)
    pts2 = barcode.rect#通过将barcode.rect赋值给变量pts2，我们可以使用这个变量来访问和操作条形码的边界框信息。边界框信息通常包括条形码的左上角坐标、宽度和高度。
    cv2.putText(img,myData,(pts2[0],pts2[1]),cv2.FONT_HERSHEY_SIMPLEX,
                0.9,(255,0,255),2)

cv2.imshow('Result',img)
cv2.waitKey(0)
cv2.destroyAllWindows()